﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIM_Labyrint
{
    [System.Flags]
     public enum COLLIDERSIDE
    {
        UP,
        DOWN,
        LEFT,
        RIGHT
    }
}
