﻿namespace database
{
    public class Life
    {
        public string life { get; set; }
        public int Id { get; set; }
    }
}
