﻿namespace database
{
    public class Character
    {
        public string Score { get; set; }
        public int Id { get; set; }
    }
}
