﻿
namespace database
{
    public class Musik
    {
            public bool T { get; set; }
            public int Id { get; set; }
    }
}

